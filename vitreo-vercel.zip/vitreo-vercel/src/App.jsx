import React, { useState } from 'react';
import { Upload, Send, CheckCircle, Phone, Mail, Calendar, User, Building2, FileText, Camera, Box, ChevronRight, ChevronLeft, Palette, MessageSquare, X } from 'lucide-react';

const CATALOGO_PRECIOS = {
  coronas: [
    { id: 'corona-mono-zr', nombre: 'Corona Monolítica Zirconia', precio: 1300 },
    { id: 'corona-estrat-zr', nombre: 'Corona Estratificada Zirconia', precio: 1500 },
    { id: 'corona-mono-emax', nombre: 'Corona Monolítica E-Max', precio: 1400 },
    { id: 'corona-estrat-emax', nombre: 'Corona Estratificada E-Max', precio: 1500 },
    { id: 'corona-pmma', nombre: 'Corona PMMA', precio: 1500 },
  ],
  provisionales: [
    { id: 'prov-impreso', nombre: 'Provisional Impreso', precio: 300 },
    { id: 'prov-fresado', nombre: 'Provisional Fresado', precio: 600 },
  ],
  ponticos: [
    { id: 'pontico-anat', nombre: 'Póntico Anatómico', precio: 1300 },
    { id: 'pontico-red', nombre: 'Póntico Reducido', precio: 1000 },
  ],
  incrustaciones: [
    { id: 'incrustacion', nombre: 'Incrustación / Onlay', precio: 1200 },
    { id: 'carilla', nombre: 'Carilla', precio: 1400 },
  ],
  implantes: [
    { id: 'pilar-zr', nombre: 'Pilar Personalizado Zirconia', precio: 1400 },
    { id: 'corona-implante', nombre: 'Corona sobre Implante', precio: 1500 },
  ],
  estructuras: [
    { id: 'all-on-x', nombre: 'Estructura All On X', precio: 30000 },
    { id: 'guia-simple', nombre: 'Guía Quirúrgica Simple', precio: 900 },
    { id: 'guia-compleja', nombre: 'Guía Quirúrgica Compleja', precio: 1500 },
  ],
};

const COLORES_VITA = [
  'A1', 'A2', 'A3', 'A3.5', 'A4',
  'B1', 'B2', 'B3', 'B4',
  'C1', 'C2', 'C3', 'C4',
  'D2', 'D3', 'D4',
  'BL1', 'BL2', 'BL3', 'BL4'
];

const DIENTES_SUPERIOR = [18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28];
const DIENTES_INFERIOR = [48, 47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37, 38];

export default function App() {
  const [paso, setPaso] = useState(1);
  const [enviado, setEnviado] = useState(false);
  const [numeroOrden, setNumeroOrden] = useState('');
  
  const [formData, setFormData] = useState({
    nombreDoctor: '',
    clinica: '',
    telefono: '',
    email: '',
    nombrePaciente: '',
    fechaEntrada: new Date().toISOString().split('T')[0],
    fechaSalida: '',
    modeloSuperior: false,
    modeloInferior: false,
    dientesSeleccionados: [],
    restauraciones: {},
    colorVita: '',
    fotos: [],
    archivosSTL: [],
    observaciones: '',
  });

  const totalPasos = 6;

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleDiente = (diente) => {
    setFormData(prev => {
      const seleccionados = prev.dientesSeleccionados.includes(diente)
        ? prev.dientesSeleccionados.filter(d => d !== diente)
        : [...prev.dientesSeleccionados, diente];
      
      const restauraciones = { ...prev.restauraciones };
      if (!seleccionados.includes(diente)) {
        delete restauraciones[diente];
      }
      
      return { ...prev, dientesSeleccionados: seleccionados, restauraciones };
    });
  };

  const setRestauracion = (diente, restauracion) => {
    setFormData(prev => ({
      ...prev,
      restauraciones: { ...prev.restauraciones, [diente]: restauracion }
    }));
  };

  const handleFileUpload = (type, files) => {
    const fileList = Array.from(files).map(file => ({
      name: file.name,
      size: (file.size / 1024 / 1024).toFixed(2) + ' MB',
      file: file
    }));
    setFormData(prev => ({
      ...prev,
      [type]: [...prev[type], ...fileList]
    }));
  };

  const removeFile = (type, index) => {
    setFormData(prev => ({
      ...prev,
      [type]: prev[type].filter((_, i) => i !== index)
    }));
  };

  const calcularTotal = () => {
    let total = 0;
    if (formData.modeloSuperior) total += 200;
    if (formData.modeloInferior) total += 200;
    Object.values(formData.restauraciones).forEach(rest => {
      if (rest?.precio) total += rest.precio;
    });
    return total;
  };

  const validarPaso = () => {
    switch (paso) {
      case 1:
        return formData.nombreDoctor && formData.telefono && formData.email;
      case 2:
        return formData.nombrePaciente && formData.fechaEntrada && formData.fechaSalida;
      case 3:
        return formData.dientesSeleccionados.length > 0 || formData.modeloSuperior || formData.modeloInferior;
      case 4:
        if (formData.dientesSeleccionados.length === 0) return true;
        return formData.dientesSeleccionados.every(d => formData.restauraciones[d]);
      case 5:
        if (formData.dientesSeleccionados.length === 0) return true;
        return formData.colorVita !== '';
      case 6:
        return true;
      default:
        return false;
    }
  };

  const enviarOrden = () => {
    const orden = {
      ...formData,
      numeroOrden: 'VL-' + Date.now().toString().slice(-6),
      fechaCreacion: new Date().toISOString(),
      total: calcularTotal(),
      estado: 'Recibida'
    };
    setNumeroOrden(orden.numeroOrden);
    setEnviado(true);
    
    // Aquí puedes agregar integración con email o webhook
    console.log('Orden enviada:', orden);
    
    // Enviar por email usando EmailJS o similar
    // emailjs.send('service_id', 'template_id', orden);
  };

  const BarraProgreso = () => (
    <div className="mb-8">
      <div className="flex justify-between mb-2">
        {[1, 2, 3, 4, 5, 6].map(p => (
          <div
            key={p}
            className={`w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-xs sm:text-sm font-semibold transition-all duration-300 ${
              p < paso
                ? 'bg-teal-500 text-white'
                : p === paso
                ? 'bg-teal-600 text-white ring-4 ring-teal-200'
                : 'bg-gray-200 text-gray-500'
            }`}
          >
            {p < paso ? <CheckCircle size={16} /> : p}
          </div>
        ))}
      </div>
      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-teal-500 to-cyan-500 transition-all duration-500"
          style={{ width: `${((paso - 1) / (totalPasos - 1)) * 100}%` }}
        />
      </div>
      <div className="hidden sm:flex justify-between mt-2 text-xs text-gray-500">
        <span>Doctor</span>
        <span>Paciente</span>
        <span>Dientes</span>
        <span>Trabajo</span>
        <span>Color</span>
        <span>Archivos</span>
      </div>
    </div>
  );

  if (enviado) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-white flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-2xl p-6 sm:p-8 max-w-md w-full text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle size={40} className="text-white" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">¡Orden Recibida!</h1>
          <p className="text-gray-500 mb-6">Su orden ha sido registrada exitosamente</p>
          
          <div className="bg-teal-50 rounded-2xl p-4 mb-6">
            <p className="text-sm text-teal-600 mb-1">Número de Orden</p>
            <p className="text-2xl font-bold text-teal-700">{numeroOrden}</p>
          </div>
          
          <div className="bg-gray-50 rounded-2xl p-4 mb-6 text-left">
            <p className="font-semibold text-gray-700 mb-2">Resumen:</p>
            <p className="text-sm text-gray-600">Paciente: {formData.nombrePaciente}</p>
            <p className="text-sm text-gray-600">Piezas: {formData.dientesSeleccionados.length}</p>
            <p className="text-sm text-gray-600">Entrega: {formData.fechaSalida}</p>
            <p className="text-lg font-bold text-teal-600 mt-2">Total: ${calcularTotal().toLocaleString()} MXN</p>
          </div>
          
          <p className="text-sm text-gray-500 mb-4">
            Recibirá un correo de confirmación con los detalles.
          </p>
          
          <div className="text-sm text-gray-500">
            <p className="font-semibold mb-1">¿Dudas? Contáctenos:</p>
            <p>📞 WhatsApp: +52 984 XXX XXXX</p>
            <p>📧 contacto@vitreolab.com</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-white">
      <div className="bg-gradient-to-r from-teal-600 to-cyan-600 text-white py-4 sm:py-6 px-4 shadow-lg">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight">VITREO LAB</h1>
          <p className="text-teal-100 text-sm">Orden de Trabajo Digital</p>
        </div>
      </div>

      <div className="max-w-2xl mx-auto p-4 py-6 sm:py-8">
        <BarraProgreso />

        <div className="bg-white rounded-2xl sm:rounded-3xl shadow-xl p-4 sm:p-6 md:p-8">
          {paso === 1 && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-teal-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <User size={28} className="text-teal-600" />
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Datos del Doctor</h2>
                <p className="text-gray-500 text-sm">Información de contacto del profesional</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre completo del Dr./Dra. *
                  </label>
                  <input
                    type="text"
                    value={formData.nombreDoctor}
                    onChange={(e) => handleInputChange('nombreDoctor', e.target.value)}
                    placeholder="Dr. Juan Pérez García"
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-teal-500 focus:ring-4 focus:ring-teal-100 transition-all outline-none text-base"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre de la Clínica
                  </label>
                  <div className="relative">
                    <Building2 size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      value={formData.clinica}
                      onChange={(e) => handleInputChange('clinica', e.target.value)}
                      placeholder="Clínica Dental Sonrisa"
                      className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-teal-500 focus:ring-4 focus:ring-teal-100 transition-all outline-none text-base"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Teléfono de contacto *
                  </label>
                  <div className="relative">
                    <Phone size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      type="tel"
                      value={formData.telefono}
                      onChange={(e) => handleInputChange('telefono', e.target.value)}
                      placeholder="+52 984 123 4567"
                      className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-teal-500 focus:ring-4 focus:ring-teal-100 transition-all outline-none text-base"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Correo electrónico *
                  </label>
                  <div className="relative">
                    <Mail size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="doctor@clinica.com"
                      className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-teal-500 focus:ring-4 focus:ring-teal-100 transition-all outline-none text-base"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {paso === 2 && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-cyan-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Calendar size={28} className="text-cyan-600" />
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Datos del Paciente</h2>
                <p className="text-gray-500 text-sm">Información del caso y fechas de entrega</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre completo del paciente *
                  </label>
                  <input
                    type="text"
                    value={formData.nombrePaciente}
                    onChange={(e) => handleInputChange('nombrePaciente', e.target.value)}
                    placeholder="María González López"
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-teal-500 focus:ring-4 focus:ring-teal-100 transition-all outline-none text-base"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 sm:gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Fecha entrada *
                    </label>
                    <input
                      type="date"
                      value={formData.fechaEntrada}
                      onChange={(e) => handleInputChange('fechaEntrada', e.target.value)}
                      className="w-full px-3 sm:px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-teal-500 focus:ring-4 focus:ring-teal-100 transition-all outline-none text-sm sm:text-base"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Fecha entrega *
                    </label>
                    <input
                      type="date"
                      value={formData.fechaSalida}
                      onChange={(e) => handleInputChange('fechaSalida', e.target.value)}
                      className="w-full px-3 sm:px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-teal-500 focus:ring-4 focus:ring-teal-100 transition-all outline-none text-sm sm:text-base"
                    />
                  </div>
                </div>

                <div className="bg-gradient-to-r from-teal-50 to-cyan-50 rounded-2xl p-4 border border-teal-200">
                  <p className="font-semibold text-teal-700 mb-2 text-sm sm:text-base">⏱️ Tiempos estándar:</p>
                  <ul className="text-xs sm:text-sm text-teal-600 space-y-1">
                    <li>• Coronas y puentes: <strong>24-48 horas</strong></li>
                    <li>• Casos complejos: <strong>72 horas</strong></li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {paso === 3 && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl sm:text-3xl">🦷</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Odontograma</h2>
                <p className="text-gray-500 text-sm">Seleccione las piezas dentales a trabajar</p>
              </div>

              <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-4 border border-purple-200">
                <p className="font-semibold text-purple-700 mb-3 text-sm sm:text-base">🖨️ Modelos 3D Impresos (Opcional)</p>
                <div className="flex flex-wrap gap-2 sm:gap-3">
                  <label className={`flex items-center gap-2 px-3 sm:px-4 py-2 sm:py-3 rounded-xl cursor-pointer transition-all text-sm ${
                    formData.modeloSuperior 
                      ? 'bg-purple-500 text-white shadow-lg' 
                      : 'bg-white text-gray-700 hover:bg-purple-100'
                  }`}>
                    <input
                      type="checkbox"
                      checked={formData.modeloSuperior}
                      onChange={(e) => handleInputChange('modeloSuperior', e.target.checked)}
                      className="sr-only"
                    />
                    <span>Modelo Superior</span>
                    <span className="font-bold">$200</span>
                  </label>
                  <label className={`flex items-center gap-2 px-3 sm:px-4 py-2 sm:py-3 rounded-xl cursor-pointer transition-all text-sm ${
                    formData.modeloInferior 
                      ? 'bg-purple-500 text-white shadow-lg' 
                      : 'bg-white text-gray-700 hover:bg-purple-100'
                  }`}>
                    <input
                      type="checkbox"
                      checked={formData.modeloInferior}
                      onChange={(e) => handleInputChange('modeloInferior', e.target.checked)}
                      className="sr-only"
                    />
                    <span>Modelo Inferior</span>
                    <span className="font-bold">$200</span>
                  </label>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium text-gray-600 mb-2 text-center">ARCADA SUPERIOR</p>
                <div className="flex justify-center gap-1 flex-wrap">
                  {DIENTES_SUPERIOR.map(diente => (
                    <button
                      key={diente}
                      onClick={() => toggleDiente(diente)}
                      className={`w-8 h-10 sm:w-10 sm:h-12 rounded-lg text-xs font-bold transition-all ${
                        formData.dientesSeleccionados.includes(diente)
                          ? 'bg-teal-500 text-white shadow-lg scale-105'
                          : 'bg-gray-100 text-gray-600 hover:bg-teal-100'
                      }`}
                    >
                      {diente}
                    </button>
                  ))}
                </div>
              </div>

              <div className="border-t-2 border-dashed border-gray-300 my-4" />

              <div>
                <p className="text-sm font-medium text-gray-600 mb-2 text-center">ARCADA INFERIOR</p>
                <div className="flex justify-center gap-1 flex-wrap">
                  {DIENTES_INFERIOR.map(diente => (
                    <button
                      key={diente}
                      onClick={() => toggleDiente(diente)}
                      className={`w-8 h-10 sm:w-10 sm:h-12 rounded-lg text-xs font-bold transition-all ${
                        formData.dientesSeleccionados.includes(diente)
                          ? 'bg-teal-500 text-white shadow-lg scale-105'
                          : 'bg-gray-100 text-gray-600 hover:bg-teal-100'
                      }`}
                    >
                      {diente}
                    </button>
                  ))}
                </div>
              </div>

              {(formData.dientesSeleccionados.length > 0 || formData.modeloSuperior || formData.modeloInferior) && (
                <div className="bg-teal-50 rounded-2xl p-4 border border-teal-200">
                  <p className="font-semibold text-teal-700 text-sm sm:text-base">
                    ✅ Seleccionado: {formData.dientesSeleccionados.length} pieza(s)
                    {formData.modeloSuperior && ' + Modelo Superior'}
                    {formData.modeloInferior && ' + Modelo Inferior'}
                  </p>
                </div>
              )}
            </div>
          )}

          {paso === 4 && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-amber-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <FileText size={28} className="text-amber-600" />
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Tipo de Restauración</h2>
                <p className="text-gray-500 text-sm">Configure el trabajo para cada pieza</p>
              </div>

              {formData.dientesSeleccionados.length === 0 ? (
                <div className="bg-gray-50 rounded-2xl p-6 text-center">
                  <p className="text-gray-500">Solo se solicitaron modelos 3D.</p>
                  <p className="text-gray-400 text-sm">No es necesario configurar restauraciones.</p>
                </div>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {formData.dientesSeleccionados.sort((a, b) => a - b).map(diente => (
                    <div key={diente} className="bg-gray-50 rounded-2xl p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 bg-teal-500 text-white rounded-xl flex items-center justify-center font-bold text-sm">
                          {diente}
                        </div>
                        <span className="font-medium text-gray-700 text-sm">Pieza {diente}</span>
                        {formData.restauraciones[diente] && (
                          <span className="ml-auto text-teal-600 font-bold text-sm">
                            ${formData.restauraciones[diente].precio.toLocaleString()}
                          </span>
                        )}
                      </div>
                      <select
                        value={formData.restauraciones[diente]?.id || ''}
                        onChange={(e) => {
                          const selected = Object.values(CATALOGO_PRECIOS)
                            .flat()
                            .find(item => item.id === e.target.value);
                          setRestauracion(diente, selected);
                        }}
                        className="w-full px-3 sm:px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-teal-500 focus:ring-4 focus:ring-teal-100 transition-all outline-none bg-white text-sm"
                      >
                        <option value="">Seleccionar tipo de trabajo...</option>
                        <optgroup label="👑 Coronas">
                          {CATALOGO_PRECIOS.coronas.map(item => (
                            <option key={item.id} value={item.id}>
                              {item.nombre} - ${item.precio.toLocaleString()}
                            </option>
                          ))}
                        </optgroup>
                        <optgroup label="🔧 Provisionales">
                          {CATALOGO_PRECIOS.provisionales.map(item => (
                            <option key={item.id} value={item.id}>
                              {item.nombre} - ${item.precio.toLocaleString()}
                            </option>
                          ))}
                        </optgroup>
                        <optgroup label="🌉 Pónticos">
                          {CATALOGO_PRECIOS.ponticos.map(item => (
                            <option key={item.id} value={item.id}>
                              {item.nombre} - ${item.precio.toLocaleString()}
                            </option>
                          ))}
                        </optgroup>
                        <optgroup label="💎 Incrustaciones y Carillas">
                          {CATALOGO_PRECIOS.incrustaciones.map(item => (
                            <option key={item.id} value={item.id}>
                              {item.nombre} - ${item.precio.toLocaleString()}
                            </option>
                          ))}
                        </optgroup>
                        <optgroup label="🔩 Implantes">
                          {CATALOGO_PRECIOS.implantes.map(item => (
                            <option key={item.id} value={item.id}>
                              {item.nombre} - ${item.precio.toLocaleString()}
                            </option>
                          ))}
                        </optgroup>
                        <optgroup label="🏗️ Estructuras y Guías">
                          {CATALOGO_PRECIOS.estructuras.map(item => (
                            <option key={item.id} value={item.id}>
                              {item.nombre} - ${item.precio.toLocaleString()}
                            </option>
                          ))}
                        </optgroup>
                      </select>
                    </div>
                  ))}
                </div>
              )}

              {calcularTotal() > 0 && (
                <div className="bg-gradient-to-r from-teal-500 to-cyan-500 rounded-2xl p-4 text-white">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Subtotal:</span>
                    <span className="text-xl sm:text-2xl font-bold">${calcularTotal().toLocaleString()} MXN</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {paso === 5 && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-orange-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Palette size={28} className="text-orange-600" />
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Color VITA</h2>
                <p className="text-gray-500 text-sm">Seleccione el color de la guía VITA</p>
              </div>

              {formData.dientesSeleccionados.length === 0 ? (
                <div className="bg-gray-50 rounded-2xl p-6 text-center">
                  <p className="text-gray-500">Solo se solicitaron modelos 3D.</p>
                  <p className="text-gray-400 text-sm">No es necesario seleccionar color.</p>
                </div>
              ) : (
                <div className="grid grid-cols-5 gap-2">
                  {COLORES_VITA.map(color => (
                    <button
                      key={color}
                      onClick={() => handleInputChange('colorVita', color)}
                      className={`py-2 sm:py-3 px-1 sm:px-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                        formData.colorVita === color
                          ? 'bg-teal-500 text-white shadow-lg scale-105'
                          : 'bg-gray-100 text-gray-700 hover:bg-teal-100'
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              )}

              {formData.colorVita && (
                <div className="bg-teal-50 rounded-2xl p-4 border border-teal-200 text-center">
                  <p className="text-teal-700">
                    Color seleccionado: <span className="font-bold text-lg sm:text-xl">{formData.colorVita}</span>
                  </p>
                </div>
              )}
            </div>
          )}

          {paso === 6 && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Upload size={28} className="text-blue-600" />
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Archivos y Observaciones</h2>
                <p className="text-gray-500 text-sm">Adjunte fotos, archivos STL y notas</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Camera size={16} className="inline mr-2" />
                  Fotos del caso (JPG, PNG)
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-2xl p-4 sm:p-6 text-center hover:border-teal-400 transition-colors">
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={(e) => handleFileUpload('fotos', e.target.files)}
                    className="hidden"
                    id="upload-fotos"
                  />
                  <label htmlFor="upload-fotos" className="cursor-pointer">
                    <Camera size={28} className="mx-auto text-gray-400 mb-2" />
                    <p className="text-gray-500 text-sm">Clic para seleccionar fotos</p>
                  </label>
                </div>
                {formData.fotos.length > 0 && (
                  <div className="mt-3 space-y-2">
                    {formData.fotos.map((file, i) => (
                      <div key={i} className="flex items-center justify-between bg-gray-50 rounded-xl p-3">
                        <span className="text-sm text-gray-600 truncate flex-1">{file.name}</span>
                        <button
                          onClick={() => removeFile('fotos', i)}
                          className="text-red-500 hover:bg-red-100 p-1 rounded-lg ml-2"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Box size={16} className="inline mr-2" />
                  Archivos digitales (STL, PLY)
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-2xl p-4 sm:p-6 text-center hover:border-teal-400 transition-colors">
                  <input
                    type="file"
                    multiple
                    accept=".stl,.ply"
                    onChange={(e) => handleFileUpload('archivosSTL', e.target.files)}
                    className="hidden"
                    id="upload-stl"
                  />
                  <label htmlFor="upload-stl" className="cursor-pointer">
                    <Box size={28} className="mx-auto text-gray-400 mb-2" />
                    <p className="text-gray-500 text-sm">Clic para seleccionar archivos 3D</p>
                  </label>
                </div>
                {formData.archivosSTL.length > 0 && (
                  <div className="mt-3 space-y-2">
                    {formData.archivosSTL.map((file, i) => (
                      <div key={i} className="flex items-center justify-between bg-gray-50 rounded-xl p-3">
                        <span className="text-sm text-gray-600 truncate flex-1">{file.name}</span>
                        <button
                          onClick={() => removeFile('archivosSTL', i)}
                          className="text-red-500 hover:bg-red-100 p-1 rounded-lg ml-2"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <MessageSquare size={16} className="inline mr-2" />
                  Observaciones o indicaciones especiales
                </label>
                <textarea
                  value={formData.observaciones}
                  onChange={(e) => handleInputChange('observaciones', e.target.value)}
                  placeholder="Escriba cualquier indicación adicional..."
                  rows={3}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-teal-500 focus:ring-4 focus:ring-teal-100 transition-all outline-none resize-none text-base"
                />
              </div>

              <div className="bg-gradient-to-br from-teal-50 to-cyan-50 rounded-2xl p-4 sm:p-6 border border-teal-200">
                <h3 className="font-bold text-base sm:text-lg text-gray-800 mb-4">📋 Resumen de la Orden</h3>
                <div className="space-y-2 text-sm">
                  <p><span className="text-gray-500">Doctor:</span> <span className="font-medium">{formData.nombreDoctor}</span></p>
                  <p><span className="text-gray-500">Paciente:</span> <span className="font-medium">{formData.nombrePaciente}</span></p>
                  <p><span className="text-gray-500">Entrega:</span> <span className="font-medium">{formData.fechaSalida}</span></p>
                  <p><span className="text-gray-500">Piezas:</span> <span className="font-medium">{formData.dientesSeleccionados.join(', ') || 'Ninguna'}</span></p>
                  {formData.colorVita && <p><span className="text-gray-500">Color VITA:</span> <span className="font-medium">{formData.colorVita}</span></p>}
                  {formData.modeloSuperior && <p className="text-purple-600">✓ Modelo Superior ($200)</p>}
                  {formData.modeloInferior && <p className="text-purple-600">✓ Modelo Inferior ($200)</p>}
                </div>
                <div className="mt-4 pt-4 border-t border-teal-200">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-gray-700">TOTAL:</span>
                    <span className="text-2xl sm:text-3xl font-bold text-teal-600">${calcularTotal().toLocaleString()} MXN</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-between mt-6 sm:mt-8 pt-4 sm:pt-6 border-t border-gray-100">
            <button
              onClick={() => setPaso(p => p - 1)}
              disabled={paso === 1}
              className={`flex items-center gap-1 sm:gap-2 px-4 sm:px-6 py-2 sm:py-3 rounded-xl font-medium transition-all text-sm sm:text-base ${
                paso === 1
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <ChevronLeft size={18} />
              Anterior
            </button>

            {paso < totalPasos ? (
              <button
                onClick={() => setPaso(p => p + 1)}
                disabled={!validarPaso()}
                className={`flex items-center gap-1 sm:gap-2 px-4 sm:px-6 py-2 sm:py-3 rounded-xl font-medium transition-all text-sm sm:text-base ${
                  validarPaso()
                    ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white hover:shadow-lg hover:scale-105'
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
              >
                Siguiente
                <ChevronRight size={18} />
              </button>
            ) : (
              <button
                onClick={enviarOrden}
                className="flex items-center gap-1 sm:gap-2 px-5 sm:px-8 py-2 sm:py-3 rounded-xl font-bold bg-gradient-to-r from-teal-500 to-cyan-500 text-white hover:shadow-lg hover:scale-105 transition-all text-sm sm:text-base"
              >
                <Send size={18} />
                Enviar Orden
              </button>
            )}
          </div>
        </div>

        <div className="text-center mt-6 sm:mt-8 text-xs sm:text-sm text-gray-500">
          <p>Vitreo Laboratorio Dental © 2024</p>
          <p>Innovación y Precisión en cada sonrisa</p>
        </div>
      </div>
    </div>
  );
}
